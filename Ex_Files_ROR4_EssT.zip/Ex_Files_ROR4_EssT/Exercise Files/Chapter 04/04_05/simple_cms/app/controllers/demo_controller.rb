class DemoController < ApplicationController

  layout false

  def index
  end
end
