# Be sure to restart your server when you modify this file.

SimpleCms::Application.config.session_store :cookie_store, key: '_simple_cms_session'
